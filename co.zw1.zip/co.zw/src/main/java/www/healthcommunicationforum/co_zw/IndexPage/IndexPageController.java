package www.healthcommunicationforum.co_zw.IndexPage;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class IndexPageController {

 //   public redirectIndex (){}

}
